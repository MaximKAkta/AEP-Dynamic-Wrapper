/*
 Copyright 2020 Adobe. All rights reserved.
 This file is licensed to you under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License. You may obtain a copy
 of the License at http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software distributed under
 the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 OF ANY KIND, either express or implied. See the License for the specific language
 governing permissions and limitations under the License.
 */

#import <Foundation/Foundation.h>

//! Project version number for AEPIdentity.
FOUNDATION_EXPORT double AEPIdentityVersionNumber;

//! Project version string for AEPIdentity.
FOUNDATION_EXPORT const unsigned char AEPIdentityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AEPIdentity/PublicHeader.h>
